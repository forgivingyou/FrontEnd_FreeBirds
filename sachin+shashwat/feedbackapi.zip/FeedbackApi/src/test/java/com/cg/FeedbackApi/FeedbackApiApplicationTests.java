package com.cg.FeedbackApi;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cg.FeedbackApi.bean.FeedbackResponse;
import com.cg.FeedbackApi.dao.FeedbackDao;
import com.cg.FeedbackApi.entities.Product;
import com.cg.FeedbackApi.exception.SameFeedbackException;
import com.cg.FeedbackApi.service.FeedbackService;


@ExtendWith(SpringExtension.class)
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest
class FeedbackApiApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Autowired
	FeedbackService feedbackService;
	
	@Autowired
	FeedbackDao feedbackDao;
	
	
	// this testcases will run only when product table will have product with product id 1 and customer with username="viking"
	// 	and "shash". 
	// Product and Customer Details were not in our module . So I inserted some data manually in my table.
	@Test
	@Order(1)
	public void submitFeedbackTest1() throws SameFeedbackException{
		FeedbackResponse feedback=new FeedbackResponse(1,4,"Best phone","I love this phone",1,"viking","");
		assertEquals("submitted successfully",feedbackService.submitFeedback(feedback));
	}
	
	@Test
	@Order(2)
	public void submitFeedbackTest2() throws SameFeedbackException{
		FeedbackResponse feedback=new FeedbackResponse(1,4,"Best phone","I love this phone",1,"viking","");
		assertThrows(SameFeedbackException.class,()->feedbackService.submitFeedback(feedback),"You can't give feedback twice");
	}
	
	@Test
	@Order(3)
	public void checkRating1() {
		Product product=feedbackDao.getProduct(1);
		assertEquals(4,product.getProductRating());
	}
	
	@Test
	@Order(4)
	public void submitFeedbackTest3() throws SameFeedbackException{
		FeedbackResponse feedback=new FeedbackResponse(2,2,"Good product","Can play pubg for 1 hour",1,"shash","");
		assertEquals("submitted successfully",feedbackService.submitFeedback(feedback));
	}
	
	@Test
	@Order(5)
	public void checkRating2() {
		Product product=feedbackDao.getProduct(1);
		assertEquals(3,product.getProductRating());
	}
	
	@Test
	@Order(6)
	public void getFeedbackTest(){
		List<FeedbackResponse> feedback=feedbackService.getFeedback("1");
		assertEquals(2,feedback.size());
	}

}
