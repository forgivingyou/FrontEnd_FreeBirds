package com.cg.FeedbackApi.exception;

public class SameFeedbackException extends Exception {
	
	public SameFeedbackException() {
	super("You can't give feedback twice");
	}
}
