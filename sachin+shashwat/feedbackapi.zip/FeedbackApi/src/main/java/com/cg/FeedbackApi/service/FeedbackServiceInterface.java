package com.cg.FeedbackApi.service;

import java.util.List;

import com.cg.FeedbackApi.bean.FeedbackResponse;
import com.cg.FeedbackApi.exception.SameFeedbackException;

public interface FeedbackServiceInterface {
	
	public List<FeedbackResponse> getFeedback(String productId);
	
	public String submitFeedback(FeedbackResponse feedback) throws SameFeedbackException;
	
//	public String updateFeedback(FeedbackResponse feedback);
	
//	public String deleteFeedback(String productId);

}
