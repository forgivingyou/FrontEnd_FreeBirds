package com.cg.FeedbackApi.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="CUSTOMERS")
public class CustomerDetails implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USERNAME")
	private String username;
	
	@Column(name="NAME")
	private String name;
	
	@OneToMany(mappedBy="customer")
	private Set<ProductFeedback> productFeedbacks = new HashSet<ProductFeedback>();

	@Override
	public String toString() {
		return "CustomerDetails [username=" + username + ", name=" + name + ", productFeedbacks=" + productFeedbacks
				+ "]";
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@JsonIgnore
	public Set<ProductFeedback> getProductFeedbacks() {
		return productFeedbacks;
	}

	public void setProductFeedbacks(Set<ProductFeedback> productFeedbacks) {
		this.productFeedbacks = productFeedbacks;
	}

}
