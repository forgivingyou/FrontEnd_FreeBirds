package com.cg.FeedbackApi.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.FeedbackApi.bean.FeedbackResponse;
import com.cg.FeedbackApi.controller.FeedbackController;
import com.cg.FeedbackApi.dao.FeedbackDao;
import com.cg.FeedbackApi.entities.Product;
import com.cg.FeedbackApi.entities.ProductFeedback;
import com.cg.FeedbackApi.exception.SameFeedbackException;


@Service
public class FeedbackService implements FeedbackServiceInterface{

	@Autowired
	FeedbackDao feedDao;
	
	private Logger logger=Logger.getLogger(FeedbackService.class);
		
	@Override
	public List<FeedbackResponse> getFeedback(String productId) {
		// TODO Auto-generated method stub
		List<ProductFeedback> allFeedback=feedDao.getFeedback();
		List<FeedbackResponse> response=filterFeedbackById(allFeedback,productId);	
		logger.info(response.size()+" feedbacks are there for product id : "+productId);	// log to see no of feedback
		return response;
	}
	
	@Override
	public String submitFeedback(FeedbackResponse feedback) throws SameFeedbackException{
	
		// checking if same user for same product;
		checkFeedback(feedback);						// can throw Exception
		
		ProductFeedback newfeed=new ProductFeedback();
		// setting value to entities
		newfeed.setFeedbackId(feedback.getId());
		newfeed.setFeedbackMessage(feedback.getFeedbackMessage());
		newfeed.setFeedbackSubject(feedback.getFeedbackSubject());
		newfeed.setRating(feedback.getRating());
		
		newfeed.setCustomer(feedDao.getCustomer(feedback.getUsername()));
		newfeed.setProduct(feedDao.getProduct(feedback.getProductId()));
		
		// send data to dao layer
		feedDao.addFeedback(newfeed);
		
		//updating rating
		updateProductRating(feedback);
		
		logger.info("feedback saved for product id :"+feedback.getProductId());
		return "submitted successfully";
	}

	public void updateProductRating(FeedbackResponse feedback){
		int pId=feedback.getProductId();
		Product product=feedDao.getProduct(pId);
		List<FeedbackResponse> feedbacks=filterFeedbackById(feedDao.getFeedback(),pId+"");
		float noOfFeed=feedbacks.size()-1;	
		float productRating=product.getProductRating(); 
		
		int newRating=Math.round(((noOfFeed*productRating)+feedback.getRating())/feedbacks.size());
		product.setProductRating(newRating);
		feedDao.updateProduct(product);
	}

	// check feedback
	public void checkFeedback(FeedbackResponse feedback) throws SameFeedbackException{
		List<ProductFeedback> feedbacks=feedDao.getFeedback();
		for(int i=0;i<feedbacks.size();i++) {
			String username=feedbacks.get(i).getCustomer().getUsername();
			int productId=feedbacks.get(i).getProduct().getProductId();
			if(username.equals(feedback.getUsername()) && productId==feedback.getProductId())
			{
				logger.error("Same user is giving feedbackfor same product");
				throw new SameFeedbackException();
			}
		}
	}
	
	// helper method to filter feedback as per provided id
	public List<FeedbackResponse> filterFeedbackById(List<ProductFeedback> allFeedback,String productId)
	{
		List<FeedbackResponse> response=new ArrayList<>();
		for(int i=0;i<allFeedback.size();i++)
		{
			ProductFeedback feedback=allFeedback.get(i);
			if(feedback.getProduct().getProductId()==Integer.parseInt(productId))
			{
				FeedbackResponse resp=makeResponse(allFeedback.get(i));
				response.add(resp);
			}
		}
		return response;
	}
	
	
	// to convert ProductFeedback object to data which can be used by UI. We are not sending full information to the UI
	public FeedbackResponse makeResponse(ProductFeedback feed) {
		FeedbackResponse response=new FeedbackResponse(feed.getFeedbackId() , feed.getRating() , feed.getFeedbackSubject(), 
				feed.getFeedbackMessage() , feed.getProduct().getProductId() , feed.getCustomer().getUsername() , feed.getCustomer().getName()
				);
		return response;
	}
	
	
}
