package com.cg.FeedbackApi.bean;

public class FeedbackResponse {
	    private int id;
	    private int rating;
	    private String feedbackSubject;
	    private String feedbackMessage;
	    private int productId;
	    private String username;
	    private String name;			// customer name
	    
		public FeedbackResponse(int id, int rating, String feedbackSubject, String feedbackMessage, int productId,
				String username, String name) {
			this.id = id;
			this.rating = rating;
			this.feedbackSubject = feedbackSubject;
			this.feedbackMessage = feedbackMessage;
			this.productId = productId;
			this.username = username;
			this.name = name;
		}
		
		

		@Override
		public String toString() {
			return "FeedbackResponse [id=" + id + ", rating=" + rating + ", feedbackSubject=" + feedbackSubject
					+ ", feedbackMessage=" + feedbackMessage + ", productId=" + productId + ", username=" + username
					+ ", name=" + name + "]";
		}



		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public int getRating() {
			return rating;
		}

		public void setRating(int rating) {
			this.rating = rating;
		}

		public String getFeedbackSubject() {
			return feedbackSubject;
		}

		public void setFeedbackSubject(String feedbackSubject) {
			this.feedbackSubject = feedbackSubject;
		}

		public String getFeedbackMessage() {
			return feedbackMessage;
		}

		public void setFeedbackMessage(String feedbackMessage) {
			this.feedbackMessage = feedbackMessage;
		}

		public int getProductId() {
			return productId;
		}

		public void setProductId(int productId) {
			this.productId = productId;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
}
