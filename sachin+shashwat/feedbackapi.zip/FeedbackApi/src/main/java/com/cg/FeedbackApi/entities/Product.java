package com.cg.FeedbackApi.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="PRODUCTS")
public class Product implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="PROD_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productId;
	
	@Column(name="PROD_NAME")
	private String productName;
	
	@Column(name="PROD_RATING")
	private int productRating;
	
	@OneToMany(mappedBy="product")
	@JsonIgnore
	private Set<ProductFeedback> feedbacks = new HashSet<>();


	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productRating=" + productRating
				+ ", feedbacks=" + feedbacks + "]";
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public int getProductRating() {
		return productRating;
	}


	public void setProductRating(int productRating) {
		this.productRating = productRating;
	}

	@JsonIgnore
	public Set<ProductFeedback> getFeedbacks() {
		return feedbacks;
	}


	public void setFeedbacks(Set<ProductFeedback> feedbacks) {
		this.feedbacks = feedbacks;
	}

	public void addFeedback(ProductFeedback feedback) {
		feedback.setProduct(this);
		this.getFeedbacks().add(feedback);
		
	}
	
	public void removeFeedback(ProductFeedback feedback) {
		feedback.setProduct(null);
		this.getFeedbacks().remove(feedback);
		
	}
}
