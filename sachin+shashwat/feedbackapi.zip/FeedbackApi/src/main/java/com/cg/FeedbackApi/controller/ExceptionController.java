package com.cg.FeedbackApi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cg.FeedbackApi.exception.SameFeedbackException;

@RestControllerAdvice
public class ExceptionController {
	
	@ExceptionHandler(SameFeedbackException.class)
	public ResponseEntity<String> handleError1(SameFeedbackException e) {
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.UNAUTHORIZED);
	}
}
