package com.cg.FeedbackApi.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.FeedbackApi.entities.CustomerDetails;
import com.cg.FeedbackApi.entities.Product;
import com.cg.FeedbackApi.entities.ProductFeedback;


@Repository
@Transactional
public class FeedbackDao implements FeedbackDaoInterface{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<ProductFeedback> getFeedback() {
		String query="SELECT a FROM ProductFeedback a";
		return em.createQuery(query, ProductFeedback.class).getResultList();
	}

	
	@Override
	public void addFeedback(ProductFeedback feedback) {
		em.persist(feedback);
	}
	
	// for updation of product rating
	public void updateProduct(Product product) {
		em.merge(product);
	}

	// while add feedback, customer details are required.
	public CustomerDetails getCustomer(String id) {
		return em.find(CustomerDetails.class, id);
	}
	
	// while add feedback, product details are required.
	public Product getProduct(int id) {
		return em.find(Product.class,id);
	}
	
}
