package com.cg.FeedbackApi.dao;

import java.util.List;

import com.cg.FeedbackApi.entities.ProductFeedback;

public interface FeedbackDaoInterface {

	public List<ProductFeedback> getFeedback();
	
	public void addFeedback(ProductFeedback feedback);

}
