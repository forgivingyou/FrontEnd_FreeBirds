import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Feedback } from '../models/feedback.model';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  //Injecting HttpClient service to make rest api calls.
  constructor(private http: HttpClient) { }

  baseUrl: string = "http://localhost:8080/feedback";

  //GET - getFeedbacksById()
  getFeedbackById(id: number) {
    return this.http.get<Feedback[]>(this.baseUrl + "/" + id);
  }
  //POST - createNewFeedback()
  createNewFeedback(Feedback: Feedback) {
    return this.http.post(this.baseUrl+"/submit", Feedback,{responseType:'text'});
  }

  //DELETE - deleteFeedbackById()
  deleteFeedbackById(id: number) {
    return this.http.delete(this.baseUrl + "/delete/" + id);
  }
}