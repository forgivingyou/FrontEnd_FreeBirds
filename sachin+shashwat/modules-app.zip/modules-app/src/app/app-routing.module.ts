import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductFeedbackComponent } from './components/product-feedback/product-feedback.component';


const routes: Routes = [
  {path:"product",component:ProductFeedbackComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
