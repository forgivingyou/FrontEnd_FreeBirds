import { Component, OnInit } from '@angular/core';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-product-feedback',
  templateUrl: './product-feedback.component.html',
  styleUrls: ['./product-feedback.component.css']
})
export class ProductFeedbackComponent implements OnInit {

  searchText: any;
  //to handle list of Feedback
  feedbacks: Feedback[];
  constructor(private feedbackService: FeedbackService) { 
    this.feedbackService.getFeedbackById(2).subscribe(data => {
      this.feedbacks = data;
    },
      err => {
        //on reject or on error
        console.log(err.stack);
      })
  }

  ngOnInit() {
  }
  
}

