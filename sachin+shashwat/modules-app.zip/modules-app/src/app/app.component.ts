import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FeedbackService } from './services/feedback.service';
import { Feedback } from './models/feedback.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'plp-feedback-module';
  feedbackForm: FormGroup;
  submitted: boolean = false;
  feedback:Feedback;

  constructor(private formBuilder: FormBuilder,private feedbackService:FeedbackService, private router: Router) { }

  ngOnInit() {
      this.feedbackForm = this.formBuilder.group({
      rating: ['', [Validators.required, Validators.pattern("[1-5]{1}")]],
      subject: ['', [Validators.required, Validators.pattern("^[a-zA-Z0-9 ]{1,80}$")]],
      message: ['', [Validators.required, Validators.pattern("^[a-zA-Z0-9 ]{1,500}$")]]
    });
  }

  onSubmit() {
    this.submitted = true;
    if(this.feedbackForm.invalid){
      return ;
    }

    this.feedback=new Feedback();
    this.feedback.rating=Number(this.feedbackForm.controls.rating.value);
    this.feedback.feedbackMessage=this.feedbackForm.controls.message.value;
    this.feedback.feedbackSubject=this.feedbackForm.controls.subject.value;
    this.feedback.productId=1;          //    Number(localStorage.getItem('ProductId'));
    this.feedback.username="viking";    //  localStorage.getItem('Username');
    this.feedback.name="";

    console.log(this.feedback);

    this.feedbackService.createNewFeedback(this.feedback).subscribe(
      data=>{
        alert(data);
      },
      err=>{
        alert(err.error);
      }
    )
  }
}