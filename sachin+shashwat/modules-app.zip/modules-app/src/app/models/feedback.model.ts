//creating user model class
export class Feedback{
    id: number;         // this is feedback id
    rating: number;
    feedbackSubject: string;
    feedbackMessage: string;
    productId:number;
    username:string;
    name:string;
}