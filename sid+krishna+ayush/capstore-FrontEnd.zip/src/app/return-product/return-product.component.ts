import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-return-product',
  templateUrl: './return-product.component.html',
  styleUrls: ['./return-product.component.css']
})
export class ReturnProductComponent implements OnInit {

  constructor(private fb:FormBuilder) { }

  productId:number=10110007;
  productCost:number=78000;
  productName:string="Iphone X, 4GB 64GB";

  ngOnInit() {
  }

  returnForm=this.fb.group({
    description:['',Validators.required],
    reason:['',Validators.required]
  });

  returnProduct(){
    alert("product returned, your amount will be refunded soon!");
    this.returnForm.reset();
  }

}
