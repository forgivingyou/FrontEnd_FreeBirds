export class Wallet{
    userName:string;
    balance:number;
}