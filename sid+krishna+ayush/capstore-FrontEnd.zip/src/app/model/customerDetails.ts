export class customerDetails{
    userName:string;
    name:string;
    phoneNo:string;
    alternatePhoneNo:string;
    alternateEmail:string;
    gender:string;
    balance:number;
}