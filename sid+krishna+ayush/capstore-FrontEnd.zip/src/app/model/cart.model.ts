import { Product } from './Product';
import { customerDetails } from './customerDetails';

export class Cart{
    id:number;
    customer:customerDetails;
    product:Product;
    quantity:number;
    setQuantity(){
        this.quantity=1;
    }
    setProduct(product:Product){
        this.product=product;
    }
}