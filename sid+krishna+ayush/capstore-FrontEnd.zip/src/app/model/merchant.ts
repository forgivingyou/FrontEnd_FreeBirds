export class MerchantDetails{
    userName:string;
    name:string;
    phoneNo:string;
    alternatePhoneNo:string;
    alternateEmail:string;
    isThirdParty:boolean;
    isDeleted:boolean;
    gender:string;
}