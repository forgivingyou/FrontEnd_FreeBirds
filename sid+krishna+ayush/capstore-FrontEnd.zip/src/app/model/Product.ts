import { MerchantDetails } from './merchant';

export class Product{
    productId:number;
    productName:string;
    productImage:string;
    productPrice:number;
    productRating:number;
    noOfViews:number;
    productBrand:string;
    noOfProducts:number;
    merchant:MerchantDetails;
}