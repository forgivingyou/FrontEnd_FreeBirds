import { Component, OnInit } from '@angular/core';
import { Product } from '../model/Product';
import { Cart } from '../model/cart.model';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit {
  totalAmount:number;
  //products: string[]=["Iphone X, 4GB 64GB","Rolex Excalibu DBEX0422","RayBan SunGlass 4185"];
  
  //merchant:String[]=["ABC Dealers","XYZ Sellers","123 Dealers"];

  //cost:string[]=["78,000","56,10,599 ","11,813"];
  
 // quantity:number[]=[1,1,1];
  cart:Cart[];
  constructor(private cartService:CartService) { }
  ngOnInit() {
    
    
  }
  myCart(){
  this.cartService.getCustomerCart("dummyCust").subscribe(data=>{
    this.cart=data;
    this.totalAmount=0;
    for(let i=0;i<this.cart.length;i++){
      this.totalAmount=this.totalAmount+this.cart[i].product.productPrice*this.cart[i].quantity;
    }
    console.log(this.cart);
  },err=>{
    console.log(err.stack);
  })
}
  increaseCount(i:number){
    //this.quantity[i]=this.quantity[i]+1;
    this.cart[i].quantity=this.cart[i].quantity+1;
    this.totalAmount=this.totalAmount+this.cart[i].product.productPrice;
  }
  decreaseCount(i:number){
    //this.quantity[i]=this.quantity[i]-1;
    if(this.cart[i].quantity==1){
      return;
    }
    this.cart[i].quantity=this.cart[i].quantity-1;
    this.totalAmount=this.totalAmount-this.cart[i].product.productPrice;
  }
  removeProductFromCart(i:number){
    
    this.cartService.removeProductFromCart(this.cart[i].id).subscribe(data=>{
      if(data){
        alert("product is successfully removed from your cart");
      }
    },err=>{
      console.log(err.stack);
    })
    this.totalAmount=this.totalAmount-this.cart[i].product.productPrice;
    this.cart.splice(i,1);
  }
}
