import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../model/Product';
import { Cart } from '../model/cart.model';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  baseUrl:string="http://localhost:8080/";
  constructor(private http:HttpClient) { }

  getAllProduct(){
    return this.http.get<Product[]>(this.baseUrl+"getAllProd/");
  }
  addProductToCart(cart:Cart,userName:string){
    return this.http.post<boolean>(this.baseUrl+"addProductTocart"+"/"+userName,cart);
  }
  getCustomerCart(userName:string){
    return this.http.get<Cart[]>(this.baseUrl+"getCustomerCart"+"/"+userName);
  }
  removeProductFromCart(id:number){
    return this.http.delete<boolean>(this.baseUrl+"removeProductFromCart"+"/"+id);
  }
}





