import { Component, OnInit } from '@angular/core';
import { CartService } from './service/cart.service';
import { Product } from './model/Product';
import { Cart } from './model/cart.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'plp';
  products:Product[];
  cart:Cart;
  constructor(private cartService:CartService,private router:Router){

  }
  ngOnInit(){
    this.cartService.getAllProduct().subscribe(data=>{
      this.products=data;
    },err=>{
      console.log(err.stack);
    })
  }
  addToCart(i:number){
    this.cart=new Cart();
    this.cart.setQuantity();
    this.cart.setProduct(this.products[i]);
    this.cartService.addProductToCart(this.cart,"dummyCust").subscribe(data=>{
      console.log(data);
      if(data){
        alert("Product added successfully to your cart...");
      }
    })
  }
}
