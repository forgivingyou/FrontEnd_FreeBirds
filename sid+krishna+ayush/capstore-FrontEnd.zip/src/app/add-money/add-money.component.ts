import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { WalletService } from '../service/wallet.service';



@Component({
  selector: 'app-add-money',
  templateUrl: './add-money.component.html',
  styleUrls: ['./add-money.component.css']
})
export class AddMoneyComponent implements OnInit {
  @Input()
  balance: number;
  depositeForm:FormGroup;
  cardForm:FormGroup;
  constructor(private fb: FormBuilder,private walletService:WalletService) { }

  ngOnInit() {
    console.log(this.balance);

    this.depositeForm = this.fb.group({
      addThrough: ['', Validators.required],
      amount: ['', [Validators.required, Validators.pattern("^-?[0-9]\\d*(\\.\\d{1,2})?$"), Validators.min(1)]]
    });
    this.depositeForm.controls.amount.setValue(this.balance);
  
    this.cardForm = this.fb.group({
      CardNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{16}$")]],
      Pin: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{4}$")]],
      HolderName: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      Cvv: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{3}$")]],
      Month: ['', Validators.required],
      Year: ['', Validators.required]
    });
  }
 

  addMoneyInWallet(){
    this.balance=this.balance+ parseFloat(this.depositeForm.controls.amount.value);
    this.walletService.addMoneyToWallet("dummyCust",parseFloat(this.depositeForm.controls.amount.value)).subscribe(data=>{
      console.log(data);
      if(data){
        alert("money is successfully added in your wallet.....");
      }
    },err=>{
      console.log(err.stack);
    })
    this.cardForm.reset();
    this.depositeForm.reset();
  }

}