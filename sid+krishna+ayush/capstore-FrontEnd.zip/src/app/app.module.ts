import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddMoneyComponent } from './add-money/add-money.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { ReturnProductComponent } from './return-product/return-product.component';
import { TopNavbarComponent } from './shared/navbars/top-navbar/top-navbar.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    AddMoneyComponent,
    AddToCartComponent,
    ReturnProductComponent,
    TopNavbarComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
