import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { HomeComponent } from './home/home.component';
import { AddMoneyComponent } from './add-money/add-money.component';
import { ReturnProductComponent } from './return-product/return-product.component';


const routes: Routes = [
  { path:'home', component: HomeComponent },
  { path: '', redirectTo:'home', pathMatch:'full'},
  { path:"addMoney", component:AddMoneyComponent},
  { path:"cart", component:AddToCartComponent},
  { path:'returnProduct', component:ReturnProductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
